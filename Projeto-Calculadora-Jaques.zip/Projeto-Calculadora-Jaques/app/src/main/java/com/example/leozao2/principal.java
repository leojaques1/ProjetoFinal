package com.example.leozao2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;


public class principal extends AppCompatActivity {
    Button btnExcluir;
    Button btnDeslogar;

    EditText IntN1;
    EditText IntN2;

    Button But1;
    Button But2;
    Button But3;
    Button But4;


    TextView resultadotxt;


    public ListView listView;
    private SQLiteDatabase bancoDados;
    public ArrayList<Integer> arrayIds;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);


        vincular();
        listener();

        btnExcluir = (Button) findViewById(R.id.btnExcluir);


        btnExcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {deletar();}

        });

        btnDeslogar = (Button) findViewById(R.id.btnDeslogar);

        btnDeslogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deslogar();
            }
        });

    }

    public void deletar(){
        try{
            bancoDados = openOrCreateDatabase("baselog", MODE_PRIVATE, null);
            String sql = "DELETE FROM usuarios";
            SQLiteStatement stmt = bancoDados.compileStatement(sql);
            stmt.executeUpdateDelete();
            bancoDados.close();
            finish();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void deslogar(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }


    private void vincular(){
        IntN1 = findViewById(R.id.IntN1);
        IntN2 = findViewById(R.id.IntN2);
        But1 = findViewById(R.id.But1);
        But2 = findViewById(R.id.But2);
        But3 = findViewById(R.id.But3);
        But4 = findViewById(R.id.But4);
        resultadotxt = findViewById(R.id.resultadotxt);
    }
    private void listener(){
        But1.setOnClickListener(evt -> sub1());
        But2.setOnClickListener(evt -> sub2());
        But3.setOnClickListener(evt -> mul1());
        But4.setOnClickListener(evt -> som1());

    }
    private void sub1(){
        String strnumero1 = IntN1.getText().toString();
        String strnumero2 = IntN2.getText().toString();

        double numero1 = Double.parseDouble(strnumero1);
        double numero2 = Double.parseDouble(strnumero2);

        double resultado = numero1 - numero2;

        resultadotxt.setText(String.valueOf(resultado));

    }
    private void sub2(){
        String strnumero1 = IntN1.getText().toString();
        String strnumero2 = IntN2.getText().toString();

        double numero1 = Double.parseDouble(strnumero1);
        double numero2 = Double.parseDouble(strnumero2);

        double resultado = numero2 - numero1;

        resultadotxt.setText(String.valueOf(resultado));

    }
    private void mul1(){
        String strnumero1 = IntN1.getText().toString();
        String strnumero2 = IntN2.getText().toString();

        double numero1 = Double.parseDouble(strnumero1);
        double numero2 = Double.parseDouble(strnumero2);

        double resultado = numero1*numero2;

        resultadotxt.setText(String.valueOf(resultado));

    }
    private void som1(){
        String strnumero1 = IntN1.getText().toString();
        String strnumero2 = IntN2.getText().toString();

        double numero1 = Double.parseDouble(strnumero1);
        double numero2 = Double.parseDouble(strnumero2);

        double resultado = numero1 + numero2;

        resultadotxt.setText(String.valueOf(resultado));

    }
}



