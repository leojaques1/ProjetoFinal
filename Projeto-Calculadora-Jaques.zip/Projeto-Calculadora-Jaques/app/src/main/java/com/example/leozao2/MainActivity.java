package com.example.leozao2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText txtUsuario, txtSenha;
    Button btnEntrar, btnCadastro;
    private SQLiteDatabase bancoDados;
    Cursor i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtUsuario = (EditText) findViewById(R.id.txtNewLogin);
        txtSenha = (EditText) findViewById(R.id.txtSenha);
        btnEntrar = (Button) findViewById(R.id.btnEntrar);
        btnCadastro = (Button) findViewById(R.id.btnCadastro);
        BancoDeDados();

        btnCadastro.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){ abrirTelaCadastro(); }
        });

        btnEntrar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){ abrirTelaPrincipal(); }

        });
    }

    public void BancoDeDados(){

        try {
            bancoDados = openOrCreateDatabase("baselog", MODE_PRIVATE, null);
            bancoDados.execSQL("CREATE TABLE IF NOT EXISTS usuarios(" +
                    " id INTEGER PRIMARY KEY AUTOINCREMENT" +
                    " , user VARCHAR" +
                    " , senha VARCHAR)");
            bancoDados.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void abrirTelaPrincipal(){
        try{
            bancoDados = openOrCreateDatabase("baselog", MODE_PRIVATE, null);
            Cursor meucursor = bancoDados.rawQuery("SELECT * from usuarios where user = '" + txtUsuario.getText().toString() + "' and senha = '" + txtSenha.getText().toString() + "'" , null);
            meucursor.moveToFirst();
            if(meucursor.getCount() >0){
                Intent intent = new Intent(this, principal.class);
                startActivity(intent);
            } else{
                Toast.makeText(this, "erro", Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){e.printStackTrace();}

    }

    public void abrirTelaCadastro(){


        Intent intent = new Intent(this,Cadastrar.class);
        startActivity(intent);
    }


}


